import os
import wellcounter_imaging_module as wim

# Enter the path to the video to be analyzed
#data_dir = "/Users/saoirsekelleher/Documents/Research/QAEco/Paramecium/critter_counting/videos/"  # Location of video file
data_dir = "C:\\Users\\estern\\Documents\\critter_counting\\optimising\\experiment-validations\\videos" 
#data_dir = "C:\\Users\\estern\\Documents\\critter_counting\\videos"  # Location of video file
video_file = "2025_05_31_06_45_Temp24_Conc015_Col1_Well37.avi"
video_path = os.path.join(data_dir, video_file)

wim.add_grid_to_video(video_path)
